

.. This file contains all links we use for documentation in a centralized place
.. Place here references to all citations in lower case

.. _numpy: https://numpy.scipy.org
.. _scipy: https://www.scipy.org
.. _pytest: https://pytest.org
.. _miniconda: https://docs.conda.io/en/latest/miniconda.html
.. _setuptools: https://pypi.org/project/setuptools/
.. _sphinx: https://www.sphinx-doc.org
.. _panda: https://pandas.pydata.org/docs/
