.. image::	https://github.com/CedricLienhard/M05_miniProject/actions/workflows/ci-testing.yml/badge.svg?branch=main
   :target: https://github.com/CedricLienhard/M05_miniProject/actions/workflows/ci-testing.yml 
.. image:: 	https://coveralls.io/repos/github/CedricLienhard/M05_miniProject/badge.svg?branch=main
   :target: https://coveralls.io/github/CedricLienhard/M05_miniProject?branch=main 
.. image:: 	https://img.shields.io/badge/github-project-0000c0.svg?branch=main
   :target: https://github.com/CedricLienhard/M05_miniProject
.. image::  https://img.shields.io/badge/docs-latest-orange.svg
   :target: https://cedriclienhard.github.io/M05_miniProject/

======================================
 M05 - Mini project : Reproducibility
======================================

This bundle contains the code we used to build a reproducible project while following the M05 course. 


For installation and usage instructions, please refer to our documentation,
that can be accessed through the relevant badge above.

